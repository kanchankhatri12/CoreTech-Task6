<?php
session_start();
include("db.php");

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = $_POST['phone'];

    if (!empty($_FILES['profile_pic']['name'])) {
        $profile_pic = "uploads/" . time() . "_" . basename($_FILES['profile_pic']['name']);
        move_uploaded_file($_FILES['profile_pic']['tmp_name'], $profile_pic);
        $sql = "UPDATE students SET phone='$phone', profile_pic='$profile_pic' WHERE id=$student_id";
    } else {
        $sql = "UPDATE students SET phone='$phone' WHERE id=$student_id";
    }
    mysqli_query($conn, $sql);
}

$student = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM students WHERE id=$student_id"));
$results = mysqli_query($conn, "SELECT * FROM results WHERE student_id=$student_id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0f0f0f, #1a1a1a);
            color: #fff;
            font-family: "Segoe UI", sans-serif;
        }
        .dashboard-card {
            background: #1e1e1e;
            border: none;
            border-radius: 15px;
            box-shadow: 0px 4px 15px rgba(255, 0, 127, 0.3);
            padding: 20px;
            margin-bottom: 20px;
        }
        .btn-vvip {
            background: #ff007f;
            color: white;
            border-radius: 12px;
            padding: 10px 20px;
            border: none;
        }
        .btn-vvip:hover {
            background: #e60073;
        }
        .profile-pic {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            border: 3px solid #ff007f;
            object-fit: cover;
        }
        .table-dark th {
            background: #ff007f !important;
            color: #fff !important;
        }
        h2 {
            color: #ff007f;
        }
    </style>
</head>
<body class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Welcome, <?= $student['name'] ?></h2>
        <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>

    <div class="row">
        <!-- Left Profile Section -->
       <div class="col-md-4">
    <div class="dashboard-card text-center">
        <?php
        $roll_no = strtolower($student['roll_no']); // roll number ko lowercase me lo
        $img_path = "uploads/" . $roll_no . ".jpg"; // uploads/rollno.jpg
        if (!file_exists($img_path)) {
            $img_path = "uploads/default.png"; // agar nahi mila toh default dikhao
        }
        ?>
        <img src="<?= $img_path ?>" class="profile-pic mb-3">

        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="phone" value="<?= $student['phone'] ?>" placeholder="Phone" class="form-control mb-2">
            <input type="file" name="profile_pic" class="form-control mb-2">
            <button type="submit" class="btn-vvip w-100">Update Profile</button>
        </form>
    </div>
</div>


        <!-- Right Details Section -->
        <div class="col-md-8">
            <div class="dashboard-card">
                <h4>Your Details</h4>
                <p><b>Roll No:</b> <?= $student['roll_no'] ?></p>
                <p><b>Email:</b> <?= $student['email'] ?></p>
                <p><b>Semester:</b> <?= $student['semester'] ?></p>
            </div>

            <div class="dashboard-card">
                <h4>Results</h4>
                <table class="table table-bordered table-dark text-center">
                    <tr><th>Subject</th><th>Marks</th><th>Semester</th></tr>
                    <?php if (mysqli_num_rows($results) > 0): ?>
                        <?php while($r = mysqli_fetch_assoc($results)): ?>
                            <tr>
                                <td><?= $r['subject'] ?></td>
                                <td><?= $r['marks'] ?></td>
                                <td><?= $r['semester'] ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="3">No results uploaded yet</td></tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
