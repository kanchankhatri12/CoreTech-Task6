<?php
session_start();
$conn = new mysqli("localhost", "root", "", "student_portal");

// Agar form submit hua
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $roll_no = $_POST['roll_no'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $semester = $_POST['semester'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Default profile image
    $profile_pic = "uploads/default.png";

    // File upload (agar user image choose kare)
    if (!empty($_FILES['profile_pic']['name'])) {
        $fileName = strtolower($roll_no) . ".jpg"; 
        $target = "uploads/" . $fileName;
        move_uploaded_file($_FILES['profile_pic']['tmp_name'], $target);
        $profile_pic = $target;
    }

    // Database insert
    $sql = "INSERT INTO students (roll_no, name, email, phone, semester, password, profile_pic)
            VALUES ('$roll_no', '$name', '$email', '$phone', '$semester', '$password', '$profile_pic')";
    if ($conn->query($sql) === TRUE) {
        // Redirect to login page after register
        header("Location: login.php?registered=1");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0d0d0d; color: #fff; font-family: 'Poppins', sans-serif; }
        .register-container {
            max-width: 500px; margin: 50px auto; background: #1a1a1a;
            padding: 30px; border-radius: 15px;
            box-shadow: 0px 0px 20px rgba(255, 0, 120, 0.7);
        }
        .register-container h2 { color: #ff0078; margin-bottom: 20px; text-align: center; }
        .form-control { background: #262626; border: 1px solid #444; color: #fff; }
        .form-control:focus { border-color: #ff0078; box-shadow: 0 0 8px #ff0078; background: #1a1a1a; color: #fff; }
        .form-control::placeholder { color: #bbb !important; opacity: 1; font-style: italic; }
        .btn-vvip { background: #ff0078; color: white; border: none; padding: 10px; width: 100%; font-weight: bold; border-radius: 8px; }
        .btn-vvip:hover { background: #e6006f; box-shadow: 0px 0px 12px #ff0078; }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Student Registration</h2>
        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="roll_no" class="form-control mb-2" placeholder="Roll No" required>
            <input type="text" name="name" class="form-control mb-2" placeholder="Name" required>
            <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>
            <input type="text" name="phone" class="form-control mb-2" placeholder="Phone" required>
            <input type="text" name="semester" class="form-control mb-2" placeholder="Semester" required>
            <input type="password" name="password" class="form-control mb-2" placeholder="Password" required>
            <input type="file" name="profile_pic" class="form-control mb-3">
            <button type="submit" class="btn-vvip">Register</button>
        </form>
    </div>
</body>
</html>
