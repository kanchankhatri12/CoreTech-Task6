<?php
session_start();
$conn = new mysqli("localhost", "root", "", "student_portal");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $roll_no = $_POST['roll_no'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM students WHERE roll_no='$roll_no'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $student = $result->fetch_assoc();
        if (password_verify($password, $student['password'])) {
            $_SESSION['student_id'] = $student['id'];
            header("Location: student_dashboard.php");
            exit();
        } else {
            $error = "Invalid Password!";
        }
    } else {
        $error = "Roll No not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0d0d0d; color: #fff; font-family: 'Poppins', sans-serif; }
        .login-container {
            max-width: 400px; margin: 100px auto; background: #1a1a1a;
            padding: 30px; border-radius: 15px;
            box-shadow: 0px 0px 20px rgba(255, 0, 120, 0.7);
        }
        .login-container h2 { text-align: center; margin-bottom: 25px; color: #ff0078; font-weight: bold; }
        .form-control { background: #262626; border: 1px solid #444; color: #fff; }
        .form-control:focus { border-color: #ff0078; box-shadow: 0 0 8px #ff0078; background: #1a1a1a; color: #fff; }
        .form-control::placeholder { color: #bbb !important; opacity: 1; font-style: italic; }
        .btn-vvip { background: #ff0078; color: white; font-weight: bold; border-radius: 8px; padding: 10px; width: 100%; transition: 0.3s; border: none; }
        .btn-vvip:hover { background: #e6006f; box-shadow: 0px 0px 12px #ff0078; }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Student Login</h2>
        <?php if (!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <?php if (isset($_GET['registered'])) echo "<div class='alert alert-success'>Registered successfully! Please login.</div>"; ?>
        <form method="POST">
            <input type="text" name="roll_no" class="form-control mb-3" placeholder="Roll No" required>
            <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
            <button type="submit" class="btn-vvip">Login</button>
        </form>
    </div>
</body>
</html>
