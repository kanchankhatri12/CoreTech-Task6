<?php
session_start();
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = md5($_POST['password']);  // encrypted match

    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $_SESSION['admin'] = $username;
        header("Location: admin_dashboard.php");
        exit();
    } else {
        $error = "Invalid Username or Password";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #0d0d0d;
            color: #fff;
            font-family: 'Poppins', sans-serif;
        }
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            background: #1a1a1a;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0px 0px 20px rgba(255, 0, 120, 0.7);
        }
        .login-container h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #ff0078;
            font-weight: bold;
        }
        .form-control {
            background: #262626;
            border: 1px solid #444;
            color: #fff;
        }
        .form-control:focus {
            border-color: #ff0078;
            box-shadow: 0 0 8px #ff0078;
            background: #1a1a1a;
            color: #fff;
        }
        .form-control::placeholder {
            color: #bbb !important;
            opacity: 1;
            font-style: italic;
        }
        .btn-vvip {
            background: #ff0078;
            color: white;
            font-weight: bold;
            border-radius: 8px;
            padding: 10px;
            width: 100%;
            transition: 0.3s;
            border: none;
        }
        .btn-vvip:hover {
            background: #e6006f;
            box-shadow: 0px 0px 12px #ff0078;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Admin Login</h2>
        <?php if (!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" class="form-control mb-2" required>
            <input type="password" name="password" placeholder="Password" class="form-control mb-2" required>
            <button type="submit" class="btn-vvip">Login</button>
        </form>
    </div>
</body>
</html>
