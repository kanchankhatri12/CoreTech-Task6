<?php
session_start();
include("db.php");

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

# --- Stats Queries ---
$total_students = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM students"))['total'];

# Semester distribution
$sem_data = [];
$result = mysqli_query($conn, "SELECT semester, COUNT(*) as count FROM students GROUP BY semester");
while ($row = mysqli_fetch_assoc($result)) {
    $sem_data[$row['semester']] = $row['count'];
}

# Monthly registration trend (last 6 months)
$month_data = [];
$result = mysqli_query($conn, "SELECT DATE_FORMAT(created_at,'%Y-%m') as month, COUNT(*) as count 
                               FROM students 
                               GROUP BY month 
                               ORDER BY month DESC LIMIT 6");
while ($row = mysqli_fetch_assoc($result)) {
    $month_data[$row['month']] = $row['count'];
}

$students = mysqli_query($conn, "SELECT * FROM students");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            color: #212529;
            font-family: 'Poppins', sans-serif;
        }
        h2, h3 {
            color: #ff0078;
            font-weight: bold;
        }
        .card {
            background: #ffffff !important;
            border: none;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        .table {
            background: #fff;
            color: #212529;
        }
        .table th {
            background: #ff0078;
            color: #fff;
        }
        .table tbody tr:nth-child(odd) {
            background: #f2f2f2;
        }
        .table tbody tr:nth-child(even) {
            background: #ffffff;
        }
        .table tbody tr:hover {
            background: #ffe6f0 !important;
        }
        .btn-warning {
            background: #ff0078;
            border: none;
            color: #fff;
            font-weight: bold;
        }
        .btn-warning:hover {
            background: #e6006f;
            box-shadow: 0 0 10px #ff0078;
        }
        .btn-danger {
            background: #ff0040;
            border: none;
            font-weight: bold;
            color: #fff;
        }
        .btn-danger:hover {
            background: #cc0033;
            box-shadow: 0 0 10px #ff0040;
        }
        canvas {
            background: #fff;
            border-radius: 12px;
            padding: 15px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        #searchInput {
            width: 300px;
            margin-bottom: 15px;
            border: 2px solid #ff0078;
        }
    </style>
</head>
<body class="container p-5">
    <h2>Admin Dashboard</h2>
    <a href="logout.php" class="btn btn-danger float-end">Logout</a>
    
    <!-- Quick Stats -->
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card text-center p-3">
                <h3>Total Students</h3>
                <p class="fs-2"><?= $total_students ?></p>
            </div>
        </div>
    </div>

    <!-- Charts -->
    <div class="row mt-4">
        <div class="col-md-6">
            <canvas id="semesterChart"></canvas>
        </div>
        <div class="col-md-6">
            <canvas id="monthChart"></canvas>
        </div>
    </div>

    <!-- Student Table -->
    <h3 class="mt-5">Registered Students</h3>
    <input type="text" id="searchInput" class="form-control" placeholder="Search by Name, Roll No, Semester, Email or Phone">
    
    <table class="table table-bordered mt-3" id="studentTable">
        <thead>
            <tr>
                <th>Name</th><th>Roll No</th><th>Semester</th>
                <th>Email</th><th>Phone</th><th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($s = mysqli_fetch_assoc($students)): ?>
            <tr>
                <td><?= $s['name'] ?></td>
                <td><?= $s['roll_no'] ?></td>
                <td><?= $s['semester'] ?></td>
                <td><?= $s['email'] ?></td>
                <td><?= $s['phone'] ?></td>
                <td>
                    <a href="upload_result.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-warning">Upload Result</a>
                    <a href="delete_student.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete student?')">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- ChartJS Scripts -->
    <script>
        // Table Search/Filter
        document.getElementById("searchInput").addEventListener("keyup", function() {
            let filter = this.value.toLowerCase();
            let rows = document.querySelectorAll("#studentTable tbody tr");
            rows.forEach(row => {
                let text = row.innerText.toLowerCase();
                row.style.display = text.includes(filter) ? "" : "none";
            });
        });

        // Semester Distribution
        const semLabels = <?= json_encode(array_keys($sem_data)) ?>;
        const semCounts = <?= json_encode(array_values($sem_data)) ?>;
        new Chart(document.getElementById('semesterChart'), {
            type: 'bar',
            data: {
                labels: semLabels,
                datasets: [{
                    label: 'Students per Semester',
                    data: semCounts,
                    backgroundColor: 'rgba(255, 0, 127, 0.7)'
                }]
            },
            options: { 
                plugins: { legend: { labels: { color: '#212529' } } }, 
                scales: { 
                    x: { ticks: { color: '#212529' } }, 
                    y: { ticks: { color: '#212529' } } 
                } 
            }
        });

        // Monthly Trend
        const monthLabels = <?= json_encode(array_keys(array_reverse($month_data))) ?>;
        const monthCounts = <?= json_encode(array_values(array_reverse($month_data))) ?>;
        new Chart(document.getElementById('monthChart'), {
            type: 'line',
            data: {
                labels: monthLabels,
                datasets: [{
                    label: 'Registrations (last 6 months)',
                    data: monthCounts,
                    borderColor: 'rgba(0, 123, 255, 1)',
                    backgroundColor: 'rgba(0, 123, 255, 0.2)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: { 
                plugins: { legend: { labels: { color: '#212529' } } }, 
                scales: { 
                    x: { ticks: { color: '#212529' } }, 
                    y: { ticks: { color: '#212529' } } 
                } 
            }
        });
    </script>
</body>
</html>
