<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mini Student Portal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #111; color: #fff; text-align: center; }
    .btn-vvip { background: #ff007f; color: white; border-radius: 12px; padding: 12px 20px; }
    .btn-vvip:hover { background: #e60073; }
  </style>
</head>
<body class="d-flex flex-column justify-content-center align-items-center vh-100">
  <h1 class="mb-3">🎓 Mini Student Portal</h1>
  <p>Welcome! Please select an option:</p>
  <div class="mt-3">
    <a href="register.php" class="btn btn-vvip m-2">Student Register</a>
    <a href="login.php" class="btn btn-vvip m-2">Student Login</a>
    <a href="admin_login.php" class="btn btn-vvip m-2">Admin Login</a>
  </div>
</body>
</html>
